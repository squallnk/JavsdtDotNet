﻿using Javsdt.Shared;
using Javsdt.Shared.Enum;
using Javsdt.Shared.Model;
using Javsdt.Shared.Model.Middle;
using Javsdt.Shared.Model.Property;
using Javsdt.SQL.Init;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Javsdt.SQL.Json
{
    public class WriteWorker
    {
        public static void WriteJsonToDb(string newJsonsDirectory)
        {
            // 之前收集的json所在地路径，内部有ABP、AVOP、WANZ等文件夹
            string pathDirsABPAVOP = newJsonsDirectory;
            // ABP、AVOP、WANZ等所有文件夹名称
            List<string> dirsABPAVOP = FileExplorer.GetSubDirectoriesNames(pathDirsABPAVOP);
            // ABP、AVOP、WANZ每个文件夹遍历
            foreach (string dirABP in dirsABPAVOP)
            {
                // ABP文件夹路径
                string pathDirABP = Path.Combine(pathDirsABPAVOP, dirABP);
                Console.WriteLine(pathDirABP);
                // 当前ABP文件夹下所有json的文件名
                List<string> jsons = FileExplorer.GetAllSubFilesPaths(pathDirABP, new List<string>{}, ".json");

                // 每个json开始处理
                foreach (string json in jsons)
                {
                    // json的完整路径
                    string pathJson = Path.Combine(pathDirABP, json);

                    // 读取文件内容
                    string myJsonString = File.ReadAllText(pathJson);
                    // 解析json为MovieJson类
                    MovieJson mj = JsonConvert.DeserializeObject<MovieJson>(myJsonString);
                    // 如果json文件没有数据，json无效，移动错误的json
                    if (mj == null)
                    {
                        string pathJsonError = Path.Combine(EnvSettings.PathJsonsError, json);
                        File.Move(pathJson, pathJsonError);
                        continue;
                    };
                    Console.WriteLine(mj.id);

                    // 添加新影片到数据库;
                    AddNewMovie(mj);
                    //Movie movieSearch = context.Movies.FirstOrDefault(m => m.Id == mj.dmm_id);
                    //if (movieSearch == null)
                    //{
                    //    AddNewMovie(mj);
                    //}
                    //// 如果数据库已收纳该车牌的信息，则跳过
                    //else
                    //{
                    //    Console.WriteLine("数据库已收纳！");
                    //}
                }
            }
        }

        private static void AddNewMovie(MovieJson mj)
        {
            using JavsdtContext context = new();

            // ====车牌去除左边的0====
            string[] carArrary = mj.id.Split("-");
            string carPrefString = carArrary[0];
            string carSufString = carArrary[1];    //.TrimStart('0');
                                                   //carSufString = Regex.Replace(carSufString, "[a-z]", "");

            // ====车牌前缀====
            // 数据库还不存在该车牌前缀
            if (context.CarPrefs.FirstOrDefault(carpref => carpref.Name == carPrefString) == null)
            {
                context.CarPrefs.Add(new CarPref { Name = carPrefString });
            }

            // 年份
            string release = (mj.premiered == "") ? "1970-01-01" : mj.premiered;
            // 评分
            mj.score_lib = (mj.score_lib == "") ? "0" : mj.score_lib;
            // dmm

            // ====由MovieJson转换为Movie====
            Movie movie = new Movie
            {
                // 1
                Car = mj.id,
                // 2
                CarOrigin = mj.dmm_id,
                // 3
                CarPref = carPrefString,
                // 4
                CarSuf = int.Parse(carSufString),
                // 5
                Title = mj.title,
                // 6
                TitleZh = mj.zh_title,
                // 7
                Plot = (mj.plot == "") ? null : mj.plot,
                // 8
                PlotZh = (mj.zh_plot == "") ? null : mj.zh_plot,
                // 9
                Score = byte.Parse((float.Parse(mj.score_lib) * 10).ToString()),
                // 10
                Runtime = int.Parse(mj.runtime),
                // 11
                Year = int.Parse(release.Substring(0, 4)),
                // 12
                Release = DateTime.ParseExact(release, "yyyy-MM-dd", CultureInfo.CurrentCulture),

                // 13
                FanartBase64 = null,
                // 14
                PosterCutType = PosterCutType.Left,

                // 15
                LibraryId = (mj.lib_id == "") ? null : mj.lib_id,
                // 16
                BusId = (mj.bus_id == "") ? null : mj.bus_id,
                // 17
                DbId = (mj.db_id == "") ? null : mj.db_id,
                // 18
                ArzonId = (mj.arzon_id == "") ? null : mj.arzon_id,
                // 19
                TimeModify = DateTime.Now,
            };

            #region 系列
            mj.series = (mj.series == "") ? "未知系列" : mj.series;    // 去数据库搜寻的系列
            Series seriesAlready = context.Serieses.FirstOrDefault(series => series.Name == mj.series);    // 数据库搜寻到的系列
            // 数据库还不存在该系列
            if (seriesAlready == null)
            {
                movie.Series = new Series { Name = mj.series };
            }
            else
            {
                movie.Series = seriesAlready;
            }
            #endregion

            #region 演职人员
            // =====导演====
            mj.director = (mj.director == "") ? "未知导演" : mj.director;
            Cast directorAlready = context.Casts.FirstOrDefault(cast => cast.Name == mj.director);    // 数据库搜寻到的发行商
            MovieCast movieDirector = new() { Type = CastType.Director };
            // 数据库还不存在该导演
            if (directorAlready == null)
            {
                movieDirector.Cast = new Cast { Name = mj.director };
            }
            else
            {
                movieDirector.Cast = directorAlready;
            }
            movie.MovieCasts.Add(movieDirector);

            // ==== 演员 ====
            foreach (string actorSearch in mj.actors)
            {
                Cast actorAlready = context.Casts.FirstOrDefault(a => a.Name == actorSearch);
                MovieCast movieActor = new();
                // 数据库还不存在该【演员】，添加它
                if (actorAlready == null)
                {
                    movieActor.Cast = new Cast { Name = actorSearch };
                }
                else
                {
                    movieActor.Cast = actorAlready;
                }
                movie.MovieCasts.Add(movieActor);
            }
            #endregion

            #region 制作公司
            // =====片商====
            mj.studio = (mj.studio == "") ? "未知制作室" : mj.studio;    // 去数据库搜寻的片商名称
            Company studioAlready = context.Companys.FirstOrDefault(company => company.Name == mj.studio);    // 数据库搜寻到的片商
            MovieCompany movieStudio = new();
            // 数据库还不存在该片商
            if (studioAlready == null)
            {
                movieStudio.Company = new Company { Name = mj.studio };
            }
            else
            {
                movieStudio.Company = studioAlready;
            }
            movie.MovieCompanys.Add(movieStudio);

            // =====发行商====
            mj.publisher = (mj.publisher == "") ? "未知发行商" : mj.publisher;    // 去数据库搜寻的发行商名称
            Company publisherAlready = context.Companys.FirstOrDefault(company => company.Name == mj.publisher);    // 数据库搜寻到的发行商
            MovieCompany moviePublisher = new();    // 即将赋给movie的publisher
            // 数据库还不存在该发行商
            if (publisherAlready == null)
            {
                moviePublisher.Company = new Company { Name = mj.publisher };
            }
            else
            {
                moviePublisher.Company = publisherAlready;
            }
            movie.MovieCompanys.Add(moviePublisher);
            #endregion

            #region 特征和标签
            // ==== 特征 ====
            foreach (string genreSearch in mj.genres)
            {
                Genre genreAlready = context.Genres.FirstOrDefault(g => g.NameZh == genreSearch);
                MovieGenre movieGenre = new();
                // 数据库还不存在该【特征】，添加它
                if (genreAlready == null)
                {
                    movieGenre.Genre = new Genre { NameZh = genreSearch };
                }
                else
                {
                    movieGenre.Genre = genreAlready;
                }
                movie.MovieGenres.Add(movieGenre);
            }
            #endregion

            // 收集完毕
            context.Movies.Add(movie);
            context.SaveChanges();
        }

        public string GetDmmId(MovieJson movieJson)
        {
            if (movieJson.dmm_id.StartsWith("未知") | string.IsNullOrEmpty(movieJson.dmm_id))
            {
                if (movieJson.lib_dmm.StartsWith("未知") | string.IsNullOrEmpty(movieJson.lib_dmm))
                {
                    if (movieJson.db_dmm.StartsWith("未知") | string.IsNullOrEmpty(movieJson.db_dmm))
                    {
                        return string.Empty;
                    }
                    else
                    {
                        return movieJson.db_dmm;
                    }
                }
                else
                {
                    return movieJson.lib_dmm;
                }
            }
            else
            {
                return movieJson.dmm_id;
            }
        }
    }
}
